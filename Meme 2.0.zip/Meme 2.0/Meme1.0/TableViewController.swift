//
//  TableViewController.swift
//  Meme1.0
//
//  Created by M7md on 29/04/2019.
//  Copyright © 2019 Udacity. All rights reserved.
//

import Foundation

class TableViewController: UITableViewConroller {
    
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
   // appDelegate.memes.append(meme)
}

