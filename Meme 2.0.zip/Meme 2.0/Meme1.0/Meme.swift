//
//  Meme.swift
//  Meme1.0
//
//  Created by M7md on 12/04/2019.
//  Copyright © 2019 Udacity. All rights reserved.
//
import UIKit;



struct Meme {
    var topText : String
    var bottomText : String
    var image : UIImage
    var memedImage : UIImage
}
