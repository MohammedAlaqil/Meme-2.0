//
//  Meme.swift
//  Meme 2.0
//
//  Created by M7md on 29/04/2019.
//  Copyright © 2019 Udacity. All rights reserved.
//

import Foundation
import UIKit

struct Meme {
    var topText : String
    var bottomText : String
    var originalImage : UIImage
    var memedImage : UIImage
}

